# Changelog

## 1.1.0 - 2018/11/12

- Rename to "@azure/ms-rest-azure-env"

## 1.0.0 - 2018/10/04

- Use rollup for bundling
- Use global name Azure.Environment instead of AzureEnvironment class

## 0.1.2 - 2018/08/28

- Update ActiveDirectory endpoint URL in US Government cloud

## 0.1.1 - 2018/08/24

- added batchResourceId to the supported environments

## 0.1.0 - 2017/09/16

- Initial version of ms-rest-azure-env
  - An isomorphic library that provides information about Azure endpoints for known Azure Clouds.
  - Provides a mechanism to add custom environments.
