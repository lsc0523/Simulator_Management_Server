export declare type Authenticator = (challenge: object) => Promise<string>;
//# sourceMappingURL=credentials.d.ts.map