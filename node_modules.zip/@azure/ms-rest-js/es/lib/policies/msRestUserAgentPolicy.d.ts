import { TelemetryInfo } from "./userAgentPolicy";
export declare function getDefaultUserAgentKey(): string;
export declare function getPlatformSpecificData(): TelemetryInfo[];
//# sourceMappingURL=msRestUserAgentPolicy.d.ts.map