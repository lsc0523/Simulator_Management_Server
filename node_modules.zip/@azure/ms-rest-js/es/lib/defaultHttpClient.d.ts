export { NodeFetchHttpClient as DefaultHttpClient } from "./nodeFetchHttpClient";
//# sourceMappingURL=defaultHttpClient.d.ts.map