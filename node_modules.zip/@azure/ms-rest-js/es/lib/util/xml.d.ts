export declare function stringifyXML(obj: any, opts?: {
    rootName?: string;
}): string;
export declare function parseXML(str: string): Promise<any>;
//# sourceMappingURL=xml.d.ts.map