export declare function parseXML(str: string): Promise<any>;
export declare function stringifyXML(obj: any, opts?: {
    rootName?: string;
}): string;
//# sourceMappingURL=xml.browser.d.ts.map