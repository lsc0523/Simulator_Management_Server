export { XhrHttpClient as DefaultHttpClient } from "./xhrHttpClient";
//# sourceMappingURL=defaultHttpClient.browser.d.ts.map