// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { isObjectWithProperties } from "./typeguards";
/**
 * A static name/key-based credential that supports updating
 * the underlying name and key values.
 */
var AzureNamedKeyCredential = /** @class */ (function () {
    /**
     * Create an instance of an AzureNamedKeyCredential for use
     * with a service client.
     *
     * @param name - The initial value of the name to use in authentication.
     * @param key - The initial value of the key to use in authentication.
     */
    function AzureNamedKeyCredential(name, key) {
        if (!name || !key) {
            throw new TypeError("name and key must be non-empty strings");
        }
        this._name = name;
        this._key = key;
    }
    Object.defineProperty(AzureNamedKeyCredential.prototype, "key", {
        /**
         * The value of the key to be used in authentication.
         */
        get: function () {
            return this._key;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(AzureNamedKeyCredential.prototype, "name", {
        /**
         * The value of the name to be used in authentication.
         */
        get: function () {
            return this._name;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * Change the value of the key.
     *
     * Updates will take effect upon the next request after
     * updating the key value.
     *
     * @param newName - The new name value to be used.
     * @param newKey - The new key value to be used.
     */
    AzureNamedKeyCredential.prototype.update = function (newName, newKey) {
        if (!newName || !newKey) {
            throw new TypeError("newName and newKey must be non-empty strings");
        }
        this._name = newName;
        this._key = newKey;
    };
    return AzureNamedKeyCredential;
}());
export { AzureNamedKeyCredential };
/**
 * Tests an object to determine whether it implements NamedKeyCredential.
 *
 * @param credential - The assumed NamedKeyCredential to be tested.
 */
export function isNamedKeyCredential(credential) {
    return (isObjectWithProperties(credential, ["name", "key"]) &&
        typeof credential.key === "string" &&
        typeof credential.name === "string");
}
//# sourceMappingURL=azureNamedKeyCredential.js.map