// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.

// forward declaration of Event in case DOM libs are not present.
interface Event {}
