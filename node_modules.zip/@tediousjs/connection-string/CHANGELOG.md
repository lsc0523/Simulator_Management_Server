# Changelog

## v0.3.0 (2021-01-21)

- Allow parsed SQL connection strings to return unrecognised properties [#4]

## v0.2.0 (2021-01-21)

- Parsed query strings return lowercase keys [#3]

## v0.1.0 (2021-01-21)

Initial release
