# Installation
> `npm install --save @types/pumpify`

# Summary
This package contains type definitions for pumpify (https://github.com/mafintosh/pumpify).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped.git/tree/master/types/pumpify

Additional Details
 * Last updated: Tue, 08 May 2018 16:46:27 GMT
 * Dependencies: stream, duplexify, node
 * Global values: none

# Credits
These definitions were written by Justin Beckwith <https://github.com/JustinBeckwith>, Ankur Oberoi <https://github.com/aoberoi>.
