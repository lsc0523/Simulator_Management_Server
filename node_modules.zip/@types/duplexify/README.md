# Installation
> `npm install --save @types/duplexify`

# Summary
This package contains type definitions for duplexify (https://github.com/mafintosh/duplexify).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/duplexify

Additional Details
 * Last updated: Mon, 05 Nov 2018 07:33:08 GMT
 * Dependencies: node
 * Global values: none

# Credits
These definitions were written by Sami Kukkonen <https://github.com/strax>, Jonathan Lui <https://github.com/kinwa91>.
